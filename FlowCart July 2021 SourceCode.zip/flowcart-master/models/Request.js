const mongoose = require('mongoose');
const validator = require('validator');

const requestSchema = new mongoose.Schema({
    email: {
        type: String,
        required: true,
        lowercase: true,
        trim: true,
        unique: true,
        validate(value) {
            if (!validator.isEmail(value)) {
                throw new Error('Email is invalid');
            }
        }
    },
    password: {
        type: String,
        required: true
    },
    pricingPlan: {
        type: String,
        required: true
    },
    username: {
        type: String,
        required: true,
        lowercase: true,
        unique: true,
        validate(value) {
            if (!validator.isAlphanumeric(value)) {
                throw new Error('Email is invalid');
            }
        }
    },
    status: {
        type: String,
        default: 'Pending',
        enum: {
            values: ['Pending', 'Accepted', 'Rejected'],
            message: '{VALUE} is not supported'
        }
    }
}, {collection: 'requests', timestamps: true});

module.exports = mongoose.model("Request", requestSchema);