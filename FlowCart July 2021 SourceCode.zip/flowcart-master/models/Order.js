const mongoose = require('mongoose');
const validator = require('validator');

const orderSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: true,
        trim: true
    },
    lastName: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        lowercase: true,
        trim: true,
        unique: true,
        validate(value) {
            if (!validator.isEmail(value)) {
                throw new Error('Email is invalid');
            }
        }
    },
    phoneNumber: {
        type: String,
        required: true,
        trim: true
    },
    items: {
        type: [{item: mongoose.Schema.Types.ObjectId, quantity: Number}],
        ref: 'Content'
    },
    totals: {
        type: {subtotal: Number, fee: Number, total: Number}
    }
}, {collection: 'orders', timestamps: true});

module.exports = mongoose.model('Order', orderSchema);