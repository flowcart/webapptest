const mongoose = require('mongoose');

const contentSchema = new mongoose.Schema({
    name: {
        type: String
    },
    category: {
        type: String
    },
    price: {
        type: Number // Perhaps include save function that rounds number to two decimals
    },
    stock: {
        type: Number
    },
    image: {
        type: Buffer
    }
}, {collection: 'content', timestamps: true});

module.exports = mongoose.model('Content', contentSchema);