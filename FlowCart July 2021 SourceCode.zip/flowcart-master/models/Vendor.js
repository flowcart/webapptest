const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const validator = require('validator');

const vendorSchema = new mongoose.Schema({
    email: {
        type: String,
        required: true,
        lowercase: true,
        trim: true,
        unique: true,
        validate(value) {
            if (!validator.isEmail(value)) {
                throw new Error('Email is invalid');
            }
        }
    },
    password: {
        type: String,
        required: true
    },
    pricingPlan: {
        type: String,
        required: true
    },
    username: {
        type: String,
        required: true,
        lowercase: true,
        unique: true,
        validate(value) {
            if (!validator.isAlphanumeric(value)) {
                throw new Error('Username is invalid');
            }
        }
    }
}, {collection: 'vendors', timestamps: true});

/* ---------- HOOKS ---------- */
/* ----- Pre ----- */
vendorSchema.pre('save', async function (next) {
    // Condition will hold true when new user is created or password modification
    if (this.isModified('password')) {
        this.password = await bcrypt.hash(this.password, 10);
    }

    next();
});

/* ---------- FUNCTIONS ---------- */
/* ----- Instance Methods ----- */
vendorSchema.methods.verifyPassword = function(inputPassword, callback) {
    return bcrypt.compare(inputPassword, this.password, callback);
}

module.exports = mongoose.model("Vendor", vendorSchema);