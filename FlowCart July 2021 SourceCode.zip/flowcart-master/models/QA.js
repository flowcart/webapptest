const mongoose = require('mongoose');

const qaSchema = new mongoose.Schema({
    question: String,
    answer: String
}, {collection: 'QAs'});

module.exports = mongoose.model("QA", qaSchema);