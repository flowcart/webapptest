$(document).ready(() => {
    // Sign up modal's pricing plan population
    $(`#pricing button[data-bs-toggle='modal']`).click((e) => {
        $('#pricingPlan').val($(e.currentTarget).data('plan'));
    });

    // If the page is smaller than the viewport, fix the footer to the bottom.
    if ($('body').height() < $(window).height()) {
        $('footer').addClass('fixed-bottom');
    }
});
