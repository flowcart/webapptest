const LocalStrategy = require('passport-local').Strategy;
const Vendor = require('../models/Vendor');

module.exports = function() {
    return new LocalStrategy({
            usernameField: 'username'
        },
        function (username, password, done) {
            Vendor.findOne({username}, function (err, user) {
                if (err) {
                    return done(err);
                }

                if (!user) {
                    return done(null, false);
                }
                if (!user.verifyPassword(password)) {
                    return done(null, false);
                }

                // User is verified!
                return done(null, user);
            });
        }
    )
}