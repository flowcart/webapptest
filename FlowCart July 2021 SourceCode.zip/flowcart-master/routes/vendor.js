/* ---------- MODULES ---------- */
const _ = require('lodash');
const auth = require('../middleware/auth');
const createDOMPurify = require('dompurify');
const express = require('express');
const {JSDOM} = require('jsdom');
const sgMail = require('@sendgrid/mail');

/* ---------- CONSTANTS ---------- */
const DOMPurify = createDOMPurify(new JSDOM('').window); // Use DOMPurify.sanitize(dirty) on inputs
const router = express.Router();
const Content = require('../models/Content');
const Order = require('../models/Order');
const Lead = require('../models/Lead');


/* ---------- FUNCTIONS ---------- */

/* ---------- INITIALIZATION ---------- */
/* ----- SendGrid ------ */
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

/* ---------- ROUTES ---------- */
// GET - Order Page 
router.get("/orders", (req, res) => {
    Order.find({}).populate([{path: 'items.item', model: 'Content', select: 'name price'}]).exec().then(async (orders) => {
        const items = await Content.find({});

        res.render("vendor/orders", {orders: orders, items: items});
    }).catch((err) => {
        res.status(400).redirect("/");
    });
});

// GET - Leads Page 
router.get("/leads", (req, res) => {
    Lead.find({}).then((leads) => {
        res.render("vendor/leads", {leads: leads});
    }).catch((err) => {
        res.status(400).redirect("/");
    });
});

// GET - Messages Page
router.get("/messages", (req, res) => {
    res.render("./vendor/messages");
});

//Get - Settings Page 
router.get("/settings", (req, res) => {
    res.render("./vendor/settings", {user: req.user, attempt: req.query.passwordChange});
});

module.exports = router;