/* ---------- MODULES ---------- */
const _ = require('lodash');
const auth = require('../middleware/auth');
const createDOMPurify = require('dompurify');
const express = require('express');
const {JSDOM} = require('jsdom');

/* ---------- CONSTANTS ---------- */
const DOMPurify = createDOMPurify(new JSDOM('').window); // Use DOMPurify.sanitize(dirty) on inputs
const router = express.Router();
const QA = require('../models/QA');

/* ---------- FUNCTIONS ---------- */

/* ---------- INITIALIZATION ---------- */

/* ----- Express ----- */

/* ----- Mongoose ----- */

/* ---------- ROUTES ---------- */

// GET - Content Page
router.get("/", (req, res) => {

    QA.find({}).then((QAs) => {
        res.render("client/faq", {QAs: QAs});
    }).catch((err) => {
        res.status(400).redirect("/");
    });

});

// POST - FAQ
router.post("/", (req, res) => {
    const data = req.body;

    const fields = [data.question, data.answer];

    const [question, answer] = _.map(fields, DOMPurify.sanitize);

    const qa = new QA({
        question,
        answer
    });

    qa.save().then(() => {
        res.redirect("/vendor/faq");
    }).catch((err) => {
        res.status(400).redirect("/");
    });
});

// PUT - FAQ
router.put("/:id", (req, res) => {
    const data = req.body;

    const fields = [data.question, data.answer];

    const [question, answer] = _.map(fields, DOMPurify.sanitize);

    QA.findByIdAndUpdate(req.params.id, {question, answer}, () => {
        res.redirect("/vendor/faq");
    });
});

// DELETE - FAQ
router.delete("/:id", (req, res) => {
    QA.findByIdAndDelete(req.params.id, () => {
        res.redirect("/vendor/faq");
    });
});

module.exports = router;