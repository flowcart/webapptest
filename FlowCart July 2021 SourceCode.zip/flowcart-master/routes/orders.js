/* ---------- MODULES ---------- */
const _ = require('lodash');
const auth = require('../middleware/auth');
const createDOMPurify = require('dompurify');
const express = require('express');
const {JSDOM} = require('jsdom');

/* ---------- CLASSES & INSTANCES ---------- */
const DOMPurify = createDOMPurify(new JSDOM('').window); // Use DOMPurify.sanitize(dirty) on inputs
const router = express.Router();
const Order = require('../models/Order');

/* ---------- CONSTANTS ---------- */

/* ---------- FUNCTIONS ---------- */

/* ---------- INITIALIZATION ---------- */

/* ---------- ROUTES ---------- */
// Get all orders.
router.get('/', auth.isAdmin, (req, res) => {
    Order.find({}, (err, orders) => {
        if (err) throw err;

        res.json(orders);
    });
});

// Create a order.
router.post('/', (req, res, next) => {
    const fields = [req.body.firstName, req.body.lastName, req.body.email, req.body.phoneNumber];

    const [firstName, lastName, email, phoneNumber] = _.map(fields, DOMPurify.sanitize);

    let items = [];

    if (Array.isArray(req.body.item)) {
        req.body.item.forEach((item) => {
            const data = item.split(',');

            items.push({
                quantity: data[0],
                item: data[1]
            });
        });
    } else {
        const data = req.body.item.split(',');

        items.push({
            quantity: data[0],
            item: data[1]
        });
    }

    console.log(items);

    const order = new Order({
        firstName,
        lastName,
        email,
        phoneNumber,
        items,
        totals: {subtotal: req.body.subtotal, fee: req.body.fee, total: req.body.total}
    });

    order.save((err) => {
        if (err) return res.status(409).redirect('/vendor/orders');

        return res.redirect('/vendor/orders');
    });
});

// Edit currently logged in order.
router.put('/:id', auth.isAuthenticated, (req, res) => {
    req.body.totals = {subtotal: req.body.subtotal, fee: req.body.fee, total: req.body.total};

    Order.findByIdAndUpdate(req.params.id, req.body,(err) => {
        res.redirect('/vendor/orders');
    });
});


// Delete currently logged in order.
router.delete('/', auth.isAuthenticated, (req, res) => {
    Order.findByIdAndDelete(req.order._id, (err) => {
        if (err) console.error(err);

        res.redirect('/logout');
    });
});

// Get a specific order.
router.get('/:id', auth.isAdmin, (req, res) => {
    Order.findById(req.params.id, (err, order) => {
        if (err) throw err;

        res.json(order);
    });
});

// Delete a specific order.
router.delete('/:id', auth.isAdmin, (req, res) => {
    Order.findByIdAndDelete(req.params.id, (err) => {
        if (err) throw err;

        res.redirect('/vendor/orders');
    });
});

module.exports = router;