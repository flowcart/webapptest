/* ---------- MODULES ---------- */
const _ = require('lodash');
const auth = require('../middleware/auth');
const createDOMPurify = require('dompurify');
const express = require('express');
const {JSDOM} = require('jsdom');

/* ---------- CLASSES & INSTANCES ---------- */
const DOMPurify = createDOMPurify(new JSDOM('').window); // Use DOMPurify.sanitize(dirty) on inputs
const router = express.Router();
const Lead = require('../models/Lead');

/* ---------- CONSTANTS ---------- */

/* ---------- FUNCTIONS ---------- */

/* ---------- INITIALIZATION ---------- */

/* ---------- ROUTES ---------- */
// Get all leads.
router.get('/', auth.isAdmin, (req, res) => {
    Lead.find({}, (err, leads) => {
        if (err) throw err;

        res.json(leads);
    });
});

// Create a lead.
router.post('/', (req, res, next) => {
    const fields = [req.body.firstName, req.body.lastName, req.body.email, req.body.phoneNumber];

    const [firstName, lastName, email, phoneNumber] = _.map(fields, DOMPurify.sanitize);

    const lead = new Lead({
        firstName,
        lastName,
        email,
        phoneNumber
    });

    lead.save((err) => {
        if (err) return res.status(409).redirect('/vendor/leads');

        return res.redirect('/vendor/leads');
    });
});

// Edit currently logged in lead.
router.put('/:id', auth.isAuthenticated, (req, res) => {
    Lead.findByIdAndUpdate(req.params.id, req.body,(err) => {
        res.redirect('/vendor/leads');
    });
});


// Delete currently logged in lead.
router.delete('/', auth.isAuthenticated, (req, res) => {
    Lead.findByIdAndDelete(req.lead._id, (err) => {
        if (err) console.error(err);

        res.redirect('/logout');
    });
});

// Get a specific lead.
router.get('/:id', auth.isAdmin, (req, res) => {
    Lead.findById(req.params.id, (err, lead) => {
        if (err) throw err;

        res.json(lead);
    });
});

// Delete a specific lead.
router.delete('/:id', auth.isAdmin, (req, res) => {
    Lead.findByIdAndDelete(req.params.id, (err) => {
        if (err) throw err;

        res.redirect('/vendor/leads');
    });
});

module.exports = router;