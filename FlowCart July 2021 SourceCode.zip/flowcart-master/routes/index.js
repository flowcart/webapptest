/* ---------- MODULES ---------- */
const auth = require('../middleware/auth');
const createDOMPurify = require('dompurify');
const express = require('express');
const {JSDOM} = require('jsdom');
const passport = require('passport');
const sgMail = require('@sendgrid/mail');

/* ---------- CLASSES & INSTANCES ---------- */
const DOMPurify = createDOMPurify(new JSDOM('').window); // Use DOMPurify.sanitize(dirty) on inputs
const router = express.Router();
const Vendor = require('../models/Vendor');
const Request = require('../models/Request');

/* ---------- CONSTANTS ---------- */
const DEV_MODE = process.env.LOGGED_IN === 'true'; // To automatically log in after server refresh
const DEV_USER_ID = process.env.DEV_USER_ID;

/* ---------- FUNCTIONS  ---------- */

/* ---------- INITIALIZATION ---------- */
/* ----- Express ----- */
router.use(function (req, res, next) {
    // Automatically authenticate if dev mode is on.
    if (!req.isAuthenticated() && DEV_MODE && DEV_USER_ID) {
        Vendor.findById(DEV_USER_ID, (err, user) => {
            if (err) throw err;

            req.login(user, (err) => {
                if (err) return next(err);

                return next();
            });
        });
    } else {
        next();
    }
});

/* ---------- ROUTES ---------- */
// GET '/' -
// With the middleware, if the user is not authenticated, they will be redirected to the front landing page.
router.get('/', auth.isLoggedIn, (req, res) => {
    res.render('vendor/index', {user: req.user});
});

/* ----- VISITOR ROUTES ----- */
router.get('/login', (req, res) => {
    res.render('login', {attempt: req.query.login});
});

router.post('/login', passport.authenticate('local', {successRedirect: '/', failureRedirect: '/login?login=fail'}));

router.post('/signup', (req, res) => {
    const fields = [req.body.email, req.body.password, req.body.pricingPlan, req.body.username];

    const [email, password, pricingPlan, username] = fields.map((field) => {
        return DOMPurify.sanitize(field);
    });

    const request = new Request({
        email,
        password,
        pricingPlan,
        username
    });

    request.save()
        .then(async () => {
            const adminLink = `${req.protocol}://${req.hostname}/admin`;
            const admin = await Vendor.findOne({username: 'admin'});

            // Sending notification email to the super admin
            sgMail.send({
                to: admin.email,
                from: 'alectrifysoftware@gmail.com',
                subject: 'Action Required - New Vendor Application',
                text: `
              A vendor application has been submitted, review it at the admin dashboard (make sure you're logged in!): ${adminLink}

              Application Details
              Username: ${username}
              Email: ${email}
              Pricing Plan: ${pricingPlan}
              `, html: `
                  A vendor application has been submitted, review it at the admin dashboard (make sure you're logged in!): <a href="${adminLink}">Login Page</a>
                  <br>
                  <br>
                  <details>
                        <summary>Application Details</summary>
                        <br>
                        <b>Username:</b> ${username}
                        <br>
                        <b>Email:</b> ${email}
                        <br>
                        <b>Pricing Plan:</b> ${pricingPlan}
                  </details>
                `
            }).then(() => {
            }, (error) => {
                console.error(error);

                if (error.response) {
                    console.error(error.response.body);
                }
            });

            req.flash("index", "Request has been sent to the admin for review!");
            res.redirect('/');
        })
        .catch(err => {
            req.flash("error", err.message);
            res.status(400).json('Error: ' + err);
        });
});

router.get('/privacy', (req, res) => {
    res.render('privacy');
});

router.get('/tos', (req, res) => {
    res.render('tos');
});

/* ----- USER ROUTES ----- */
router.get('/logout', auth.isAuthenticated, (req, res) => {
    req.logout();
    res.redirect('/');
});

router.get('/settings', auth.isAuthenticated, (req, res) => {
    res.render('users/settings', {attempt: req.query.passwordChange});
});

module.exports = router;