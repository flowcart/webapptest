/* ---------- MODULES ---------- */
const _ = require('lodash');
const auth = require('../middleware/auth');
const createDOMPurify = require('dompurify');
const express = require('express');
const {JSDOM} = require('jsdom');

/* ---------- CLASSES & INSTANCES ---------- */
const DOMPurify = createDOMPurify(new JSDOM('').window); // Use DOMPurify.sanitize(dirty) on inputs
const router = express.Router();
const Vendor = require('../models/Vendor');

/* ---------- CONSTANTS ---------- */

/* ---------- FUNCTIONS ---------- */

/* ---------- INITIALIZATION ---------- */

/* ---------- ROUTES ---------- */
// Get all vendors.
router.get('/', auth.isAdmin, (req, res) => {
    Vendor.find({}, (err, vendors) => {
        if (err) throw err;

        res.json(vendors);
    });
});

// Create a vendor.
router.post('/', (req, res, next) => {
    const fields = [req.body.firstName, req.body.lastName, req.body.email, req.body.password];

    const [firstName, lastName, email, password] = _.map(fields, DOMPurify.sanitize);

    const vendor = new Vendor({
        firstName,
        lastName,
        email,
        password
    });

    vendor.save((err) => {
        if (err) return res.status(409).redirect('/?login=username+taken');

        req.login(vendor, (err) => {
            if (err) return next(err);

            return res.redirect('/');
        });
    });
});

// Edit currently logged in vendor.
router.put('/', auth.isAuthenticated, (req, res) => {
    Vendor.findById(req.vendor._id, (err, vendor) => {
        if (err) console.error(err);

        // If password change attempt:
        if (req.body.oldPassword) {
            vendor.verifyPassword(req.body.oldPassword, (err, result) => {
                if (result) {
                    vendor.password = req.body.newPassword;
                    vendor.save();
                    res.redirect('/settings?passwordChange=success');
                } else {
                    res.redirect('/settings?passwordChange=fail');
                }
            });
        } else if (req.body.username) {
            vendor.username = req.body.username;
            vendor.save();
            res.redirect('/settings?passwordChange=success');
        }
        else {
            res.redirect('/');
        }
    });
});


// Delete currently logged in vendor.
router.delete('/', auth.isAuthenticated, (req, res) => {
    Vendor.findByIdAndDelete(req.vendor._id, (err) => {
        if (err) console.error(err);

        res.redirect('/logout');
    });
});

// Get a specific vendor.
router.get('/:id', auth.isAdmin, (req, res) => {
    Vendor.findById(req.params.id, (err, vendor) => {
        if (err) throw err;

        res.json(vendor);
    });
});

// Delete a specific vendor.
router.delete('/:id', auth.isAdmin, (req, res) => {
    Vendor.findByIdAndDelete(req.params.id, (err) => {
        if (err) throw err;

        res.redirect('/');
    });
});

module.exports = router;