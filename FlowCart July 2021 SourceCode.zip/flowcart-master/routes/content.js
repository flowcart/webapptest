/* ---------- MODULES ---------- */
const _ = require('lodash');
const auth = require('../middleware/auth');
const createDOMPurify = require('dompurify');
const express = require('express');
const {JSDOM} = require('jsdom');
const multer = require('multer');
const sgMail = require('@sendgrid/mail');

/* ---------- CLASSES & INSTANCES ---------- */
const DOMPurify = createDOMPurify(new JSDOM('').window); // Use DOMPurify.sanitize(dirty) on inputs
const router = express.Router();
const Content = require('../models/Content');
const Request = require('../models/Request');
const Vendor = require('../models/Vendor');

/* ---------- FUNCTIONS ---------- */

/* ---------- INITIALIZATION ---------- */
/* ----- SendGrid ------ */
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

/* ----- Multer ----- */
const upload = multer({
    fileFilter(req, file, cb) {
        const fileTypes = /jpeg|jpg|png/;
        const validMimeType = fileTypes.test(file.mimetype);

        if (validMimeType) {
            cb(null, true);
        } else {
            throw new Error("Not the correct type");
        }
    }
});

/* ---------- ROUTES ---------- */
// GET - Content Page
router.get("/", (req, res) => {

    Content.find({}).then((content) => {
        res.render("vendor/content", {content: content});
    }).catch((err) => {
        res.status(400).redirect("/");
    });

});

// POST - Content Information
router.post("/", upload.single('image'), (req, res) => {
    const data = req.body;

    const image = req.file.buffer;

    const fields = [data.name, data.category, data.price, data.stock];

    const [name, category, price, stock] = _.map(fields, DOMPurify.sanitize);

    const content = new Content({
        name,
        category,
        price,
        stock,
        image
    });

    content.save().then(() => {
        res.redirect("/vendor/content");
    }).catch((err) => {
        res.status(400).redirect("/");
    });
});


module.exports = router;