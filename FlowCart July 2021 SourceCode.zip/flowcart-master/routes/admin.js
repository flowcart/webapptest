/* ---------- MODULES ---------- */
const _ = require('lodash');
const auth = require('../middleware/auth');
const createDOMPurify = require('dompurify');
const express = require('express');
const {JSDOM} = require('jsdom');
const sgMail = require('@sendgrid/mail');

/* ---------- CLASSES & INSTANCES ---------- */
const DOMPurify = createDOMPurify(new JSDOM('').window); // Use DOMPurify.sanitize(dirty) on inputs
const router = express.Router();
const Request = require('../models/Request');
const Vendor = require('../models/Vendor');

/* ---------- CONSTANTS ---------- */

/* ---------- FUNCTIONS ---------- */

/* ---------- INITIALIZATION ---------- */
/* ----- SendGrid ------ */
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

/* ---------- ROUTES ---------- */
// ADMIN DASHBOARD
router.get('/', auth.isAdmin, async (req, res) => {
    // TODO: set up login credentials so that if they are logged in as an admin account --> in the navbar will have access to the admin tab

    const requests = await Request.find({});
    const vendors = await Vendor.find({});

    if (!requests || !vendors) {
        res.status(401).redirect('/');
    }

    res.render('admin/index', {vendors: vendors, requests: requests, flash: req.flash('accept')});
});

/* ----- Request Routes ------ */
// GET - Accept request 
router.get('/accept/:id', (req, res) => {
    Request.findByIdAndUpdate(req.params.id, {status: 'Accepted'}, (err, request) => {
        // Creating a user since request has been approved
        const vendor = new Vendor({
            email: request.email,
            password: request.password,
            pricingPlan: request.pricingPlan,
            username: request.username
        });

        vendor.save((err) => {
            if (err) {
                console.error(err);
                req.flash('accept', err);
                return res.status(409).redirect('/admin');
            }

            const loginLink = `${req.protocol}://${req.hostname}/login`;

            // Sending email with the login link
            sgMail.send({
                to: request.email,
                from: 'alectrifysoftware@gmail.com',
                subject: 'Vendor Credentials - Start Launching Your Business Now!',
                text: `
              Login and begin setting up your site here: Login Page

              Credentials
              Username: ${request.username}
              Password: ${request.password}
              
              We advise that you change your credentials & create your promotional link in the settings page after logging in!
          `,
                html: `
              Login and begin setting up your site here: <a href="${loginLink}">Login Page</a>
              <br>
              <br>
              <details>
                    <summary>Credentials</summary>
                    <br>
                    <b>Username:</b> ${request.username}
                    <br>
                    <b>Password:</b> ${request.password}
              </details>
              <br>
              <strong>
                We advise that you change your credentials & create your promotional link in the settings page after logging in!
              </strong>
        `
            }).then(() => {
            }, (error) => {
                console.error(error);

                if (error.response) {
                    console.error(error.response.body);
                }
            });

            res.redirect('/admin');
        });
    });

    /*
    let id = req.params.id;

    Request.findByIdAndUpdate(id, {status: "Accepted"}).then((request) => {
        //Creating a user since request has been approved
        const vendor = new Vendor({
            email: request.email,
            password: request.password,
            pricingPlan: request.pricingPlan,
            username: request.username
        });

        vendor.save().then((vendor) => {
            // Sending email with the login link
            sgMail.send({
                to: request.email,
                from: "alectrifysoftware@gmail.com",
                subject: "Login Page",
                text: `
              Here is login page: http://localhost:3000/login

              Username: ${request.username}
              Password: ${request.password}
          `
            }).then(() => {
            }, (error) => {
                console.error(error);

                if (error.response) {
                    console.error(error.response.body);
                }
            });

            res.redirect("/");
        }).catch((err) => {
            res.status(400).redirect("/admin");
        });
    }).catch((err) => {
        console.log(err);
    });

     */

});

// GET - Reject request 
router.get('/reject/:id', (req, res) => {
    Request.findByIdAndUpdate(req.params.id, {status: 'Rejected'}, (err) => {
        if (err) console.error(err);

        res.redirect('/admin');
    });
});

// DELETE - Delete request
router.delete('/deleteRequest/:id', (req, res) => {
    Request.findByIdAndDelete(req.params.id)
        .then(() => res.redirect('/admin'))
        .catch(err => res.status(400).json('Error: ' + err));
});


/* ----- Vendor Routes ------ */
// GET - Gets a JSON of all users.
router.get('/vendors', (req, res) => {
    Vendor.find()
        .then((users) => res.json(users))
        .catch(err => res.status(400).json('Error: ' + err));
});

// GET - Login to specified user
router.get('/login/:id', (req, res) => {
    Vendor.findById(req.params.id, (err, vendor) => {
        req.logout();

        req.login(vendor, (err) => {
            if (err) {
                console.error(err);
                return res.redirect('/');
            }

            return res.redirect('/');
        });
    });
});

// GET - Get a JSON of a user's data.
router.get('/getVendor/:id', (req, res) => {
    Vendor.findById(req.params.id)
        .then((user) => res.json(user))
        .catch(err => res.status(400).json('Error: ' + err));
})

// POST - Update a user.
router.post('/updateVendor/:id', (req, res) => {
    Vendor.findById(req.params.id)
        .then((user) => {
            user.name = DOMPurify.sanitize(req.body.name);

            user.save()
                .then(() => res.redirect('/users'))
                .catch((err) => res.status(400).json('Error: ' + err));
        })
        .catch((err) => res.status(400).json('Error: ' + err));
});

// DELETE - Delete a user.
router.delete('/deleteVendor/:id', (req, res) => {
    Vendor.findByIdAndDelete(req.params.id)
        .then(() => res.redirect('/admin'))
        .catch(err => res.status(400).json('Error: ' + err));
});

module.exports = router;